package com.car.repository;


import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.car.model.Car;
import com.car.model.CarBidding;
import com.car.model.User;

@Repository
public interface BidRepository extends JpaRepository<CarBidding, Long>{
	
	List<CarBidding> findByUserAndCar(User user, Car car);
	
	List<CarBidding> findByUser(User user);
	
	List<CarBidding> findByCar(Car car );
	
	List<CarBidding> findByCarId(Long cid );//mencari id biding


}
