package com.car;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbCarApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbCarApplication.class, args);
	}

}
